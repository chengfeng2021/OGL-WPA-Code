clc;
clear;
close all;
warning off;
addpath 'func\'
rng('default');


sel   = 12; 


idx1=0;
idx2=0;
dim   = 2;           %�����ռ�ά��
 
   
if sel == 1 | sel == 3 | sel == 4 | sel == 6 
   Lmin = -100;
   Lmax =  100;
end
if sel == 2
   Lmin = -10;
   Lmax =  10;
end
if sel == 5
   Lmin = -30;
   Lmax =  30;
end
if sel == 7
   Lmin = -5.12;
   Lmax =  5.12;
end
if sel == 8
   Lmin = -32;
   Lmax =  32;
end
if sel == 9
   Lmin = -600;
   Lmax =  600;
end
if sel == 9
   Lmin = -50;
   Lmax =  50;
end
if sel >= 10
   Lmin = -50;
   Lmax =  50;
end



c1    = 0.6;         %ѧϰ����1
c2    = 0.6;         %ѧϰ����2
w     = 0.5;         %����Ȩ��
Iters = 1000;         %����������
Num   = 50;           
%��ʼ����Ⱥ�ĸ���(�����������޶�λ�ú��ٶȵķ�Χ)
x=Lmin + (Lmax-Lmin)*rand(Num,dim);  %�����ʼ��λ��
v=Lmin + (Lmax-Lmin)*rand(Num,dim);  %�����ʼ���ٶ�

y=[];
%�ȼ���������ӵ���Ӧ�ȣ�����ʼ��Pi��Pg
for i=1:Num
    p(i)  = func_F1_10(x(i,:),sel);
    y(i,:)= x(i,:);
end
%ȫ������
pg = x(1,:);             

for i=2:Num
    pa(i) = func_F1_10(x(i,:),sel);
    pb(i) = func_F1_10(pg,sel);
    if pa(i) < pb(i)
       pg=x(i,:);
    end
end

for t=1:Iters

    for i=1:Num
        v(i,:) = w*v(i,:)+c1*randn*(y(i,:)-x(i,:))+c2*randn*(pg-x(i,:));
        x(i,:) = x(i,:)+v(i,:);
        pa(i) = func_F1_10(x(i,:),sel);
        if pa(i)<p(i)
           p(i)  = pa(i);
           y(i,:)= x(i,:);
        end

        pb(i) = func_F1_10(pg,sel);
        if p(i)<pb(i)
           pg=y(i,:);
        end
    end
    Pbest(t)  = func_F1_10(pg,sel);
end



figure;
semilogy(Pbest);

if sel == 1
   save R1.mat Pbest
end
if sel == 2
   save R2.mat Pbest
end
if sel == 3
   save R3.mat Pbest
end
if sel == 4
   save R4.mat Pbest
end
if sel == 5
   save R5.mat Pbest
end
if sel == 6
   save R6.mat Pbest
end
if sel == 7
   save R7.mat Pbest
end
if sel == 8
   save R8.mat Pbest
end
if sel == 9
   save R9.mat Pbest
end
if sel == 10
   save R10.mat Pbest
end
if sel == 11
   save R11.mat Pbest
end
if sel == 12
   save R12.mat Pbest
end


