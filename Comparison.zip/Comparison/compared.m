clc;
clear;
close all;
warning off;
addpath 'func\'




LENS=1000;
STEPS=20;

for i = 1:12
i
figure;
load(['A_�����㷨\R',num2str(i),'.mat'])
semilogy(1:STEPS:LENS,Pbest(1:STEPS:LENS),'g-^');
hold on
load(['B_ACO\R',num2str(i),'.mat'])
semilogy(1:STEPS:LENS,Pbest(1:STEPS:LENS),'k-x');
hold on
load(['C_PSO\R',num2str(i),'.mat'])
semilogy(1:STEPS:LENS,Pbest(1:STEPS:LENS),'b-*');
hold on
load(['H_GWO\R',num2str(i),'.mat'])
semilogy(1:STEPS:LENS,Pbest(1:STEPS:LENS),'r-o');
hold on
load(['I_betaGWO\R',num2str(i),'.mat'])
semilogy(1:STEPS:LENS,Pbest(1:STEPS:LENS),'b-s');
hold on
load(['J_WOA\R',num2str(i),'.mat'])
semilogy(1:STEPS:LENS,Pbest(1:STEPS:LENS),'k-<');
hold on
load(['K_LSHADE\R',num2str(i),'.mat'])
semilogy(1:STEPS:LENS,Pbest(1:STEPS:LENS),'r->');Pbest
hold on
% xlabel('��������');
% ylabel('��Ӧ��ֵ');
xlabel('Iteration times');
ylabel('Fitness value');
legend('OGL-WPA','ACO','PSO','GWO','BETAGWO','WOA','LSHADE');
 
end
 




