clc;
clear;
close all;
warning off;
addpath 'func\'
rng(1);


sel   = 12; 


idx1=0;
idx2=0;
dim   = 2;           %�����ռ�ά��
if sel == 1 | sel == 3 | sel == 4 | sel == 6 
   Lmin = -100;
   Lmax =  100;
end
if sel == 2
   Lmin = -10;
   Lmax =  10;
end
if sel == 5
   Lmin = -30;
   Lmax =  30;
end
if sel == 7
   Lmin = -5.12;
   Lmax =  5.12;
end
if sel == 8
   Lmin = -32;
   Lmax =  32;
end
if sel == 9
   Lmin = -600;
   Lmax =  600;
end
if sel == 9
   Lmin = -50;
   Lmax =  50;
end
if sel >= 10
   Lmin = -50;
   Lmax =  50;
end



w     = 0.5;         %����Ȩ��
Iters = 1000;         %����������
Num   = 50;           
%��ʼ�ǵĸ��� 
x=Lmin + (Lmax-Lmin)*rand(Num,dim);   
%̽�Ǳ�������
alpha = 1.1;
%������ߴ���
Tmax  = 20;
%�����ж�����
w     = 500;
%��������
S     = 1000;
%���±�������
beta  = 1.1;
h     = 20;


%�ȼ�������ǵ���Ӧ��
for i=1:Num
    p(i) = func_F1_10(x(i,:),sel);
end       
[V,I] = sort(p);
%ͷ��λ��
Idxlead  = I(1);
Ylead    = func_F1_10(x(Idxlead,:),sel); 
Xlead    = x(Idxlead,:);
%������
IdxD     = I(2:end);
for i=1:Num-1
    YD(i) = func_F1_10(x(IdxD(i),:),sel); 
end
XD       = x(IdxD,:);
%��ʼֵ
stepdc   = abs(Lmax-Lmin)/S;
stepdb   = 4*stepdc;
stepda   = 2*stepdc;


%������Ⱥ��ʼֵ
XleadNP  = Lmax-x(Idxlead,:);
YleadNP  = func_F1_10(XleadNP,sel); 

IdxD     = I(2:end);
XDNP     = Lmax-x(IdxD,:);
for i=1:Num-1
    YDNP(i) = func_F1_10(XDNP(I),sel); 
end
%��ʼֵ
X_all = [Xlead;XD;XleadNP;XDNP];
Y_all = [Ylead,YD,YleadNP,YDNP];

[VY,IY]= min(Y_all);
Xbest  = X_all(IY(1),:);
Ybest  = VY;
Xmean  = sum(X_all)/2/Num;
Ymean  = func_F1_10(Xmean,sel); 

if Ybest<Ymean
   Xopbest = Xbest;
else
   Xopbest = Xmean; 
end


for t=1:Iters
    t
    %������Ϊ
    tt    = 0;
    flag  = 0;
    %������Ϊ
    Snum  = round(Num/(alpha+1) + (Num/(alpha)-Num/(alpha+1))*rand);%̽������
    xid   = [];
    xid   = x(IdxD(1:Snum),:);
    Yi    = [];
    h     = Snum;
    flag  = 0; 
    while tt<=Tmax & flag==0
        for i = 1:Snum
            Yi(i) = func_F1_10(xid(i,:),sel); 
            if Yi(i)<Ylead
               Ylead = Yi(i);
               Xlead = xid(i,:);
               flag  = 1;
            else
               xid(i,:) = xid(i,:) + sin(2*pi*i/h)*stepda;
               flag     = 0;
            end
        end
        tt=tt+1;
    end
    %�ٻ���Ϊ
    Mnum  = Num-Snum-1;
    D     = Mnum;
    xid2  = [];
    xid2  = x(IdxD(Snum+1:end),:);

    xid2  = xid2 + stepdb*(repmat(Xlead,Mnum,1)-xid2)./(abs(repmat(Xlead,Mnum,1)-xid2)+1);
    dmaxm = [];
    for i = 1:D
        dmaxm(i) = max(xid2(i,:))-min(xid2(i,:));
    end
    dnear = 1/D/w*sum(dmaxm);
    Yi2   = [];
    flag2 = 0;
    while flag2==0
        for i = 1:Mnum
            Yi2(i) = func_F1_10(xid2(i,:),sel); 
            dist = sqrt(sum((xid2(i,:)-Xlead).^2));
            if Yi2(i)<Ylead
               Ylead = Yi2(i);
               Xlead = xid2(i,:);
            else
               if dist < dnear
                  flag2=1; 
               end
            end
        end
        %������Ϯ
        xid2 = xid2 + stepdb*(repmat(Xlead,Mnum,1)-xid2)./(abs(repmat(Xlead,Mnum,1)-xid2)+1);
    end
    %Χ����Ϊ
    lemda = 2*(rand-0.5);
    xidall= [xid;xid2];%���Ǻ�̽��
    [RR,CC]=size(xidall);
    Gd    = repmat(Xlead,RR,1);
    sigma1= (gamma(1+beta)*sin(pi*beta/2)/(gamma((1+beta)/2)*beta*2^((beta-1)/2)))^(1/beta);
    sigma2= 1;
    utmps = pdf('Normal',[0:10],0,sigma1);
    vtmps = pdf('Normal',[0:10],0,sigma2);
    uu    = utmps(1);
    vv    = vtmps(1);
    ss    = uu/abs(vv)^(1/beta) ;

    xidall= xidall+lemda*ss*abs(Gd-xidall);

    %����
    %���ѡ������
    indxx = randperm(Num-1);
    twos  = indxx(1:2);
    x1    = xidall(twos(1),:);
    x2    = xidall(twos(2),:);
    Xi    = Xlead;
    F     = rand;
    xv    = Xlead + F*(x1-x2);
    if rand<=0.5;%����
       xu = xv;
    else
       xu = Xi; 
    end
    %ѡ��
    if func_F1_10(xu,sel) < func_F1_10(Xlead,sel)
       Xlead2 = xu;    
    else
       Xlead2 = Xlead;
    end

    %ǿ������
    R  = round(Num/(2*beta) + (Num/(beta)-Num/(2*beta))*rand);%̽������
    for i=1:length(xidall)
        Yall(i) = func_F1_10(xidall(i,:),sel); 
    end
    [VV,II] = sort(Yall);
    %ȥ����������R��
    Xrest   = xidall(II(1:end-R),:);
    XR      = Lmin + (Lmax-Lmin)*rand(R,dim);  
    %���£����ں�һ�ε���
    x       = [Xrest;XR;Xlead];

    %�ȼ�������ǵ���Ӧ��
    for i=1:Num
        p(i) = func_F1_10(x(i,:),sel);
    end       
    [V,I] = sort(p);
    %ͷ��λ��
    Idxlead  = I(1);
    Ylead    = func_F1_10(x(Idxlead,:),sel); 
    Xlead    = x(Idxlead,:);
    %������
    IdxD     = I(2:end);
    for i=1:Num-1
        YD(i) = func_F1_10(x(IdxD(i),:),sel); 
    end
    XD       = x(IdxD,:);
    %��ʼֵ
    stepdc   = abs(Lmax-Lmin)/S;
    stepdb   = 4*stepdc;
    stepda   = 2*stepdc;


    %������Ⱥ��ʼֵ
    XleadNP  = Lmax-x(Idxlead,:);
    YleadNP  = func_F1_10(XleadNP,sel); 

    IdxD     = I(2:end);
    XDNP     = Lmax-x(IdxD,:);
    for i=1:Num-1
        YDNP(i) = func_F1_10(XDNP(I),sel); 
    end
    %��ʼֵ
    X_all = [Xlead;XD;XleadNP;XDNP];
    Y_all = [Ylead,YD,YleadNP,YDNP];

    [VY,IY]= min(Y_all);
    Xbest  = X_all(IY(1),:);
    Ybest  = VY;
    Xmean  = sum(X_all)/2/Num;
    Ymean  = func_F1_10(Xmean,sel); 

    if Ybest<Ymean
       Xopbest = Xbest;
       Ylead   = Ybest;
    else
       Xopbest = Xmean; 
       Ylead   = Ymean;
    end

    Xlead = Xopbest;


    %��ʼֵ����
    %��������
    stepc=abs(max(max(xid2))-min(min(xid2)))/S;
    %��Ϯ����
    stepb=4*stepc;
    %���߲���
    stepa=stepb/2;

    Pbest(t)=Ylead;
end



figure;
semilogy(Pbest);

if sel == 1
   save R1.mat Pbest
end
if sel == 2
   save R2.mat Pbest
end
if sel == 3
   save R3.mat Pbest
end
if sel == 4
   save R4.mat Pbest
end
if sel == 5
   save R5.mat Pbest
end
if sel == 6
   save R6.mat Pbest
end
if sel == 7
   save R7.mat Pbest
end
if sel == 8
   save R8.mat Pbest
end
if sel == 9
   save R9.mat Pbest
end
if sel == 10
   save R10.mat Pbest
end
if sel == 11
   save R11.mat Pbest
end
if sel == 12
   save R12.mat Pbest
end

