function F = func_F1_10(x,sel);

if sel == 1
   F = sum(x.^2);  
end

if sel == 2
   F = sum(abs(x)) + prod(abs(x));  
end

if sel == 3
   tmps=[]; 
   for i = 1:length(x)
       tmps(i)=sum(x(1:i));  
   end
   F = sum(tmps);
end

if sel == 4
   F = max(abs(x)); 
end

if sel == 5
   tmps=[]; 
   for i = 1:length(x)-1
       tmps(i) = 100*(x(i+1)-x(i)^2)^2 + (x(i)-1)^2;
   end
   F = sum(tmps);
end

if sel == 6
   F = sum((x+0.5).^2); 
end

if sel == 7
   F = sum([x.^2 - 10*cos(2*pi*x) + 10]); 
end

if sel == 8
   tmps1 = sqrt(sum(x.^2)/length(x));
   tmps2 = sum(cos(2*pi*x))/length(x);
   F     = 20+exp(1)-20*exp(-1/5*tmps1)-exp(tmps2);
end

if sel == 9
   tmps1 = sqrt(sum(x.^2))/1000;  
   tmps2 = cos(x(1)/1);
   for i = 2:length(x)
       tmps2 = tmps2*cos(x(i)/sqrt(i));
   end
   F = tmps1 - tmps2 + 1;
end

if sel == 10
   tmps1 = 10*sin(pi*fy(x(1)));
   tmps2 = [];
   for i = 1:length(x)-1
       tmps2(i)= (fy(x(1))-1)^2 * (1 + 10*sin(pi*fy(x(i+1)))^2);
   end
   tmps3 = (fy(x(end))-1)^2;
   
   tmps4 = [];
   for i = 1:length(x)
       tmps4(i)= fu(x(i),10,100,4);
   end
    F = pi/length(x)*(tmps1 + sum(tmps2) + tmps3) + sum(tmps4);
end

if sel == 11
   F = x(1)^2 + 10^6*sum(x(2:end).^2);  
end

if sel == 12
   tmps1 = x(1)^2;  
   for i = 2:length(x)
       tmps1 = tmps1 + i*x(i)^2;  
   end
   F = tmps1;
end


F = abs(F);
end


function y = fy(x);
y = 1+(x+1)/4;
end


function u = fu(x,a,k,m);
if x >= a
   u = k*(x-a)^m;
end
if x > -a & x <a
   u = 0;
end
if x <= -a
   u = k*(-x-a)^m;
end

end









