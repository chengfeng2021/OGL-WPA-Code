clc;
clear;
close all;
warning off;
addpath 'func\'

rng(1);


sel   = 12; 

idx1=0;
idx2=0;
dim   = 2;           %�����ռ�ά��   
if sel == 1 | sel == 3 | sel == 4 | sel == 6 
   Lmin = -100;
   Lmax =  100;
end
if sel == 2
   Lmin = -10;
   Lmax =  10;
end
if sel == 5
   Lmin = -30;
   Lmax =  30;
end
if sel == 7
   Lmin = -5.12;
   Lmax =  5.12;
end
if sel == 8
   Lmin = -32;
   Lmax =  32;
end
if sel == 9
   Lmin = -600;
   Lmax =  600;
end
if sel == 9
   Lmin = -50;
   Lmax =  50;
end
if sel >= 10
   Lmin = -50;
   Lmax =  50;
end




Ant   = dim;  %ά��
Num   = 50;  %��������
Rou   = 0.7; %��Ϣ�ػӷ�ϵ�� 
P0    = 0.2;    
Iters = 1000; 


x=Lmin + (Lmax-Lmin)*rand(Num,Ant);  %�����ʼ��λ��
for i=1:Num 
    p(i)   = func_F1_10(x(i,:),sel);
    Tau(i) = p(i);                 
end 


for t = 1:Iters 
    t
    lamda=1/t^2; 
    %ѧϰ 
    [Tau_Best(t),BestIndex]=max(Tau);
    %����״̬ת�Ƹ���
    for i=1:Num 
        Ps(i)=(Tau(BestIndex)-Tau(i))/Tau(BestIndex);  
    end 

    for i=1:Num 
        if Ps(i)<P0  %�ֲ����� 
            temp1=x(i,:)+0.5*randn(1,Ant)*lamda;       
        else  %ȫ������ 
            temp1=x(i,:)+0.5*randn(1,Ant); 
        end 
        pa(i)   = func_F1_10(temp1,sel);
        pb(i)   = func_F1_10(x(i,:),sel);

        %%% 
        if pa(i)<pb(i)  %�ж������Ƿ��ƶ� 
            x(i,:)=temp1; 
        end 
        if x(i,:)>=Lmax
           x(i,:)=Lmax;
        end
        if x(i,:)<=Lmin
           x(i,:)=Lmin;
        end
    end 
    for i=1:Num 
        pb(i) = func_F1_10(x(i,:),sel);
        Tau(i)=(1-Rou)*Tau(i)+pb(i);  %������Ϣ�� 
    end 
    Pbest(t)  = func_F1_10(temp1,sel);
end 


figure;
semilogy(Pbest);

if sel == 1
   save R1.mat Pbest
end
if sel == 2
   save R2.mat Pbest
end
if sel == 3
   save R3.mat Pbest
end
if sel == 4
   save R4.mat Pbest
end
if sel == 5
   save R5.mat Pbest
end
if sel == 6
   save R6.mat Pbest
end
if sel == 7
   save R7.mat Pbest
end
if sel == 8
   save R8.mat Pbest
end
if sel == 9
   save R9.mat Pbest
end
if sel == 10
   save R10.mat Pbest
end
if sel == 11
   save R11.mat Pbest
end
if sel == 12
   save R12.mat Pbest
end


