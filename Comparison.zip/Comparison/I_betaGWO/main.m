clc;
clear;
close all;
warning off;
addpath 'func\'
rng(1);


sel   = 11; 


idx1=0;
idx2=0;
dim   = 2;           %�����ռ�ά��

if sel == 1 | sel == 3 | sel == 4 | sel == 6 
   Lmin = -100;
   Lmax =  100;
end
if sel == 2
   Lmin = -10;
   Lmax =  10;
end
if sel == 5
   Lmin = -30;
   Lmax =  30;
end
if sel == 7
   Lmin = -5.12;
   Lmax =  5.12;
end
if sel == 8
   Lmin = -32;
   Lmax =  32;
end
if sel == 9
   Lmin = -600;
   Lmax =  600;
end
if sel == 9
   Lmin = -50;
   Lmax =  50;
end
if sel >= 10
   Lmin = -50;
   Lmax =  50;
end


Iters = 1000;         %����������
Num   = 50;       
%��ʼ����Ⱥ�ĸ���(�����������޶�λ�ú��ٶȵķ�Χ)
xpos  = Lmin + (Lmax-Lmin)*rand(Num,dim);
xpos0 = xpos;
Alpx  = zeros(1,dim);
Alps  = 1000;  
btx   = zeros(1,dim);
bts   = 1000;   
dltx  = zeros(1,dim);
dlts  = 1000; 
Pbest = zeros(1,Iters);
x1    = 0.4;
x2    = 0.6;
uu    = 2;
vv    = 2;
xc    = 3;
k     = 2;
beta_seq=[];
xt1=[];
for t=1:Iters

    for i=1:Num    
        if t > 1
           r1      = rand; 
           r2      = rand;
           A0      = 2*a*r1-a;%��ʽ5
           C0      = 2*r2;    %��ʽ6
           dd      = abs(C0*xpos(i,:)-xpos0(i,:));
           xpos(i,:) = xpos(i,:) - A0*dd;    
        end
        Yi        = func_F1_10(xpos(i,:),sel); 
        if Yi<Alps 
           Alps = Yi; 
           Alpx = xpos(i,:);
        end
        if Yi>Alps && Yi<bts 
           bts = Yi; 
           btx = xpos(i,:);
        end
        if Yi>Alps && Yi>bts && Yi<dlts 
           dlts = Yi; 
           dltx = xpos(i,:);
        end
    end
    aGWO  = 2*(1-(t/Iters));  

    for i=1:Num
        for j=1:dim    
            if xpos(i,j)>=x1 & xpos(i,j)<=x2
               beta_seq(i,j,t) = ((xpos(i,j)-x1)/(xc-x1))^uu*((x2-xpos(i,j))/(x2-xc))^vv;
            else
               beta_seq(i,j,t) = 0; 
            end
            xt1(t) = k*beta_seq(i,j,t);

            Nmmax   = max(xt1);
            Nmmin   = min(xt1);
            Nmt     = Nmmax - t*(Nmmax-Nmmin)/Iters;
            Ct      = Nmt*xpos(i,j);
            abGWO   = aGWO + Ct;
            a       = abGWO;

            r1      = rand; 
            r2      = rand;
            A1      = 2*a*r1-a;%��ʽ5
            C1      = 2*r2;    %��ʽ6
            D_alpha = abs(C1*Alpx(j)-xpos(i,j));%��ʽ7
            X1      = Alpx(j)-A1*D_alpha;       %��ʽ10

            r1      = rand; 
            r2      = rand;
            A2      = 2*a*r1-a; %��ʽ5
            C2      = 2*r2; %��ʽ6
            D_beta  = abs(C2*btx(j)-xpos(i,j)); %��ʽ8
            X2      = btx(j)-A2*D_beta; %��ʽ11    

            r1      = rand; 
            r2      = rand;
            A3      = 2*a*r1-a; %��ʽ5
            C3      = 2*r2; %��ʽ6
            D_delta = abs(C3*dltx(j)-xpos(i,j)); %��ʽ9
            X3      = dltx(j)-A3*D_delta; %��ʽ12           

            xpos(i,j) = (X1+X2+X3)/3;%��ʽ13
        end
    end
    Pbest(t) = func_F1_10(Alpx,sel); 
end
 



figure;
semilogy(Pbest);

if sel == 1
   save R1.mat Pbest
end
if sel == 2
   save R2.mat Pbest
end
if sel == 3
   save R3.mat Pbest
end
if sel == 4
   save R4.mat Pbest
end
if sel == 5
   save R5.mat Pbest
end
if sel == 6
   save R6.mat Pbest
end
if sel == 7
   save R7.mat Pbest
end
if sel == 8
   save R8.mat Pbest
end
if sel == 9
   save R9.mat Pbest
end
if sel == 10
   save R10.mat Pbest
end
if sel == 11
   save R11.mat Pbest
end
if sel == 12
   save R12.mat Pbest
end


