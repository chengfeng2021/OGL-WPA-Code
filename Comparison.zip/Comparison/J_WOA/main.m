clc;
clear;
close all;
warning off;
addpath 'func\'
rng(1);


sel   = 12; 


idx1=0;
idx2=0;
dim   = 2;        
if sel == 1 | sel == 3 | sel == 4 | sel == 6 
   Lmin = -100;
   Lmax =  100;
end
if sel == 2
   Lmin = -10;
   Lmax =  10;
end
if sel == 5
   Lmin = -30;
   Lmax =  30;
end
if sel == 7
   Lmin = -5.12;
   Lmax =  5.12;
end
if sel == 8
   Lmin = -32;
   Lmax =  32;
end
if sel == 9
   Lmin = -600;
   Lmax =  600;
end
if sel == 9
   Lmin = -50;
   Lmax =  50;
end
if sel >= 10
   Lmin = -50;
   Lmax =  50;
end


Num          = 50;  %��������
Iters        = 1000; %��������
D            = dim; %�����ռ�ά��
woa_idx      = zeros(1,D);
woa_get      = inf; 

%��ʼ����Ⱥ�ĸ���
for i=1:Num
    for j=1:D
        xwoa(i,j)=randn; %�����ʼ��λ��
    end
end 

for t=1:Iters
    t
    for i=1:Num
        %Ŀ�꺯������
        [pa(i)]  = func_F1_10(xwoa(i,:),sel);
        Fitout   = pa(i);
        %����
        if Fitout < woa_get  
            woa_get = Fitout; 
            woa_idx = xwoa(i,:);
        end
    end
    %��������
    c1 = 2-t*((1)/300); 
    c2 =-1+t*((-1)/300);
    %λ�ø���
    for i=1:Num
        r1         = rand();
        r2         = rand();
        K1         = 2*c1*r1-c1;  
        K2         = 2*r2;             
        l          =(c2-1)*rand + 1;  
        rand_flag  = rand();   

        for j=1:D
            if rand_flag<0.5  
               if abs(K1)>=1
                  RLidx    = floor(Num*rand()+1);
                  X_rand   = xwoa(RLidx, :);
                  D_X_rand = abs(K2*X_rand(j)-xwoa(i,j)); 
                  xwoa(i,j)= X_rand(j)-K1*D_X_rand;     
               else
                  D_Leader = abs(K2*woa_idx(j)-xwoa(i,j)); 
                  xwoa(i,j)= woa_idx(j)-K1*D_Leader;    
               end
            else
                distLeader = abs(woa_idx(j)-xwoa(i,j));
                xwoa(i,j)  = distLeader*exp(36*l).*cos(l.*2*pi)+woa_idx(j);
            end
        end
    end
    pb = func_F1_10(woa_idx,sel);
    Pbest(t)=pb;
end
 

figure;
semilogy(Pbest);

if sel == 1
   save R1.mat Pbest
end
if sel == 2
   save R2.mat Pbest
end
if sel == 3
   save R3.mat Pbest
end
if sel == 4
   save R4.mat Pbest
end
if sel == 5
   save R5.mat Pbest
end
if sel == 6
   save R6.mat Pbest
end
if sel == 7
   save R7.mat Pbest
end
if sel == 8
   save R8.mat Pbest
end
if sel == 9
   save R9.mat Pbest
end
if sel == 10
   save R10.mat Pbest
end
if sel == 11
   save R11.mat Pbest
end
if sel == 12
   save R12.mat Pbest
end


